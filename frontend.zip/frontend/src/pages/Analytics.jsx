import React from "react";
import { Line } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend);

const data = {
  labels: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
  datasets: [
    {
      label: "Avg Waste Level %",
      data: [45, 50, 60, 55, 65, 70, 60],
      borderColor: "rgb(34,197,94)",
      backgroundColor: "rgba(34,197,94,0.3)",
      tension: 0.4,
      pointRadius: 5,
      pointHoverRadius: 8,
      fill: true,
    },
  ],
};

const options = {
  responsive: true,
  plugins: {
    legend: {
      position: "top",
      labels: { color: "#059669", font: { size: 14, weight: "bold" } },
    },
    title: {
      display: true,
      text: "Weekly Waste Level Trends",
      color: "#059669",
      font: { size: 20, weight: "bold" },
    },
    tooltip: {
      backgroundColor: "#059669",
      titleColor: "#fff",
      bodyColor: "#fff",
    },
  },
  scales: {
    x: {
      ticks: { color: "#059669", font: { weight: "bold" } },
      grid: { color: "#d1fae5" },
    },
    y: {
      beginAtZero: true,
      ticks: { color: "#059669", font: { weight: "bold" } },
      grid: { color: "#d1fae5" },
    },
  },
};

const stats = [
  {
    label: "Total Waste Collected",
    value: "3,200 kg",
    icon: "🗑️",
    color: "bg-emerald-100 text-emerald-700",
  },
  {
    label: "Avg. Collection Time",
    value: "2.5 hrs",
    icon: "⏱️",
    color: "bg-blue-100 text-blue-700",
  },
  {
    label: "Bins Emptied",
    value: "110",
    icon: "🟩",
    color: "bg-yellow-100 text-yellow-700",
  },
  {
    label: "Alerts Resolved",
    value: "95%",
    icon: "✅",
    color: "bg-green-100 text-green-700",
  },
];

const infoSections = [
  {
    title: "How Analytics Helps",
    desc: "EcoBin analytics provides actionable insights for optimizing waste collection routes, reducing operational costs, and improving city cleanliness. By monitoring trends, city managers can make data-driven decisions for a greener future.",
    img: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=600&q=80",
  },
  {
    title: "Sustainability Impact",
    desc: "With real-time data, EcoBin helps reduce unnecessary trips, lowers fuel consumption, and minimizes carbon footprint. Our analytics empower cities to achieve sustainability goals and promote responsible waste management.",
    img: "https://images.unsplash.com/photo-1464983953574-0892a716854b?auto=format&fit=crop&w=600&q=80",
  },
];

const Analytics = () => {
  return (
    <div className="min-h-[80vh] bg-gradient-to-br from-emerald-50 to-emerald-100 py-10 px-4 flex flex-col items-center">
      <h1 className="text-4xl font-black text-emerald-800 mb-8 tracking-tight drop-shadow-lg animate-fade-in-down">
        Analytics Dashboard
      </h1>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-10 w-full max-w-6xl">
        {stats.map((stat, idx) => (
          <div
            key={stat.label}
            className={`rounded-2xl shadow-lg flex flex-col items-center justify-center p-6 ${stat.color} animate-fade-in-up`}
            style={{ animationDelay: `${0.1 + idx * 0.1}s` }}
          >
            <span className="text-3xl mb-2">{stat.icon}</span>
            <span className="text-2xl font-bold">{stat.value}</span>
            <span className="text-sm font-medium mt-1">{stat.label}</span>
          </div>
        ))}
      </div>

      {/* Chart Section */}
      <div className="w-full max-w-4xl bg-white/90 rounded-3xl shadow-2xl p-8 mb-12 animate-fade-in-up" style={{ animationDelay: "0.6s" }}>
        <Line data={data} options={options} />
      </div>

      {/* Info Sections */}
      <div className="w-full max-w-5xl flex flex-col gap-10">
        {infoSections.map((section, idx) => (
          <div
            key={section.title}
            className={`flex flex-col md:flex-row items-center gap-8 bg-white/90 rounded-2xl shadow-lg p-6 animate-fade-in-up`}
            style={{ animationDelay: `${0.7 + idx * 0.1}s` }}
          >
            <img
              src={section.img}
              alt={section.title}
              className="w-full md:w-60 h-40 object-cover rounded-xl shadow"
            />
            <div>
              <h2 className="text-xl font-bold text-emerald-800 mb-2">{section.title}</h2>
              <p className="text-emerald-700 text-base">{section.desc}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Animations */}
      <style>
        {`
          @keyframes fade-in-down {
            0% { opacity: 0; transform: translateY(-30px);}
            100% { opacity: 1; transform: translateY(0);}
          }
          @keyframes fade-in-up {
            0% { opacity: 0; transform: translateY(30px);}
            100% { opacity: 1; transform: translateY(0);}
          }
          .animate-fade-in-down {
            animation: fade-in-down 1s cubic-bezier(.4,0,.2,1) both;
          }
          .animate-fade-in-up {
            animation: fade-in-up 1s cubic-bezier(.4,0,.2,1) both;
          }
        `}
      </style>
    </div>
  );
};

export default Analytics;
