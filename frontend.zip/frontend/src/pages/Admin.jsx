import React, { useState } from "react";

const binItems = [
  "Bin #101 - Main Street",
  "Bin #102 - Park Avenue",
  "Bin #103 - Riverside",
  "Bin #104 - City Center",
  "Bin #105 - Green Plaza",
];

const teamItems = [
  "Team Alpha - North Zone",
  "Team Beta - South Zone",
  "Team Gamma - East Zone",
  "Team Delta - West Zone",
  "Team Epsilon - Central Zone",
];

const userItems = [
  "Alice Johnson (Admin)",
  "Bob Smith (Operator)",
  "Charlie Lee (Supervisor)",
  "Diana Patel (Driver)",
  "Ethan Brown (Technician)",
];

const cardData = [
  {
    title: "Manage Bins",
    items: binItems,
    color: "from-emerald-100 to-emerald-200",
  },
  {
    title: "Manage Teams",
    items: teamItems,
    color: "from-blue-100 to-blue-200",
  },
  {
    title: "Manage Users",
    items: userItems,
    color: "from-yellow-100 to-yellow-200",
  },
];

const Admin = () => {
  const [openIndex, setOpenIndex] = useState(null);

  return (
    <div className="min-h-[80vh] flex flex-col items-center justify-center bg-gradient-to-br from-emerald-50 to-emerald-100 py-10">
      <h1 className="text-3xl md:text-4xl font-black text-emerald-800 mb-10 tracking-tight drop-shadow-lg">
        Admin Panel
      </h1>
      <div className="flex flex-col md:flex-row gap-8 items-center justify-center w-full max-w-5xl">
        {cardData.map((card, idx) => (
          <div
            key={card.title}
            className={`relative flex flex-col items-center justify-center rounded-2xl shadow-lg transition-all duration-500 cursor-pointer bg-gradient-to-br ${card.color} ${
              openIndex === idx
                ? "w-[320px] md:w-[400px] min-h-[340px] z-10 scale-105"
                : "w-[180px] md:w-[220px] min-h-[120px] opacity-90 hover:scale-105"
            }`}
            onClick={() => setOpenIndex(openIndex === idx ? null : idx)}
            style={{ transitionProperty: "all" }}
          >
            <h2 className="text-xl font-bold text-emerald-900 mb-2 mt-6">
              {card.title}
            </h2>
            {openIndex === idx && (
              <ul className="mt-4 mb-6 w-full px-6 text-left animate-fade-in-up">
                {card.items.map((item, i) => (
                  <li
                    key={item}
                    className="py-2 border-b border-emerald-200 last:border-b-0 text-emerald-800 font-medium"
                  >
                    {i + 1}. {item}
                  </li>
                ))}
              </ul>
            )}
          </div>
        ))}
      </div>
      {/* Animations */}
      <style>
        {`
          @keyframes fade-in-up {
            0% { opacity: 0; transform: translateY(30px);}
            100% { opacity: 1; transform: translateY(0);}
          }
          .animate-fade-in-up {
            animation: fade-in-up 0.6s cubic-bezier(.4,0,.2,1) both;
          }
        `}
      </style>
    </div>
  );
};

export default Admin;
