import React from "react";

const binData = {
  id: 2,
  location: "Main Street",
  type: "General",
  wasteLevel: 85,
  lastEmptied: "2025-09-20",
  history: [40, 55, 70, 60, 85],
};

const ProgressBar = ({ level }) => (
  <div className="bg-gray-200 h-5 w-full rounded-full overflow-hidden shadow-inner">
    <div
      className={`h-5 rounded-full transition-all duration-700 ${
        level > 80
          ? "bg-red-500"
          : level > 50
          ? "bg-yellow-400"
          : "bg-green-500"
      }`}
      style={{ width: `${level}%` }}
    ></div>
  </div>
);

const BinDetails = () => {
  return (
    <div className="min-h-[80vh] flex flex-col items-center justify-center bg-gradient-to-br from-emerald-50 to-emerald-100 py-10 px-4">
      <div className="max-w-xl w-full bg-white/90 rounded-3xl shadow-2xl p-8 relative overflow-hidden">
        {/* Decorative Icon */}
        <div className="absolute -top-8 -right-8 opacity-20 text-emerald-400 text-[8rem] pointer-events-none select-none">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="w-32 h-32"
            viewBox="0 0 24 24"
            fill="none"
          >
            <g>
              <path d="M12 2l2.5 4.5h-5L12 2z" fill="#059669" />
              <path d="M19.5 8l-2.5-4.5-2.5 4.5h5z" fill="#34d399" />
              <path d="M4.5 8l2.5-4.5 2.5 4.5h-5z" fill="#10b981" />
            </g>
          </svg>
        </div>
        <h1 className="text-3xl font-black text-emerald-800 mb-6 tracking-tight drop-shadow-lg text-center animate-fade-in-down">
          Bin Details
        </h1>
        <div className="flex flex-col md:flex-row gap-8 items-center mb-8 animate-fade-in-up">
          {/* Bin Illustration */}
          <div className="flex-shrink-0">
            <img
              src="https://images.unsplash.com/photo-1464983953574-0892a716854b?auto=format&fit=crop&w=120&q=80"
              alt="Smart Bin"
              className="rounded-xl shadow-lg w-28 h-28 object-cover border-4 border-emerald-100"
            />
          </div>
          {/* Bin Info */}
          <div className="flex-1">
            <div className="mb-2 flex items-center gap-2">
              <span className="font-bold text-emerald-700">Bin ID:</span>
              <span className="text-lg font-semibold">{binData.id}</span>
            </div>
            <div className="mb-2 flex items-center gap-2">
              <span className="font-bold text-emerald-700">Location:</span>
              <span>{binData.location}</span>
            </div>
            <div className="mb-2 flex items-center gap-2">
              <span className="font-bold text-emerald-700">Type:</span>
              <span>{binData.type}</span>
            </div>
            <div className="mb-2 flex items-center gap-2">
              <span className="font-bold text-emerald-700">Last Emptied:</span>
              <span>{binData.lastEmptied}</span>
            </div>
          </div>
        </div>
        {/* Waste Level */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <span className="font-semibold text-emerald-700">Current Waste Level</span>
            <span
              className={`font-bold ${
                binData.wasteLevel > 80
                  ? "text-red-600"
                  : binData.wasteLevel > 50
                  ? "text-yellow-500"
                  : "text-green-600"
              }`}
            >
              {binData.wasteLevel}%
            </span>
          </div>
          <ProgressBar level={binData.wasteLevel} />
          <div className="text-xs text-gray-500 mt-1">
            {binData.wasteLevel > 80
              ? "⚠️ Needs immediate attention"
              : binData.wasteLevel > 50
              ? "Getting full, schedule soon"
              : "All good"}
          </div>
        </div>
        {/* Waste History */}
        <div className="mb-2">
          <h2 className="text-lg font-semibold text-emerald-800 mb-3">Waste History (last 5 days)</h2>
          <div className="flex gap-3 justify-between">
            {binData.history.map((h, idx) => (
              <div key={idx} className="flex flex-col items-center animate-fade-in-up">
                <div
                  className={`w-8 h-20 rounded-full flex items-end justify-center shadow-inner transition-all duration-500 ${
                    h > 80
                      ? "bg-red-400"
                      : h > 50
                      ? "bg-yellow-300"
                      : "bg-green-300"
                  }`}
                  style={{ height: `${h * 0.9 + 20}px` }}
                  title={`Day ${idx + 1}: ${h}%`}
                >
                  <span className="text-xs font-bold text-emerald-900 mb-1">{h}%</span>
                </div>
                <span className="text-xs text-gray-500 mt-1">Day {idx + 1}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
      {/* Animations */}
      <style>
        {`
          @keyframes fade-in-down {
            0% { opacity: 0; transform: translateY(-30px);}
            100% { opacity: 1; transform: translateY(0);}
          }
          @keyframes fade-in-up {
            0% { opacity: 0; transform: translateY(30px);}
            100% { opacity: 1; transform: translateY(0);}
          }
          .animate-fade-in-down {
            animation: fade-in-down 1s cubic-bezier(.4,0,.2,1) both;
          }
          .animate-fade-in-up {
            animation: fade-in-up 1s cubic-bezier(.4,0,.2,1) both;
          }
        `}
      </style>
    </div>
  );
};

export default BinDetails;
