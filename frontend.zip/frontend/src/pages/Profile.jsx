import React, { useState, useContext, useEffect } from "react";
import { AuthContext } from "../context/AuthContext";
import axios from "axios";

const Profile = () => {
  const { user, setUser, fetchUser } = useContext(AuthContext);
  const [edit, setEdit] = useState(false);
  const [form, setForm] = useState({ phone: "", address: "" });

  useEffect(() => {
    if (user) {
      setForm({
        phone: user.phone || "",
        address: user.address || "",
      });
    }
  }, [user]);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSave = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem("access_token");
      await axios.put(
        "http://127.0.0.1:8000/api/users/profile/",
        form,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      fetchUser(); // refresh user data
      setEdit(false);
    } catch (err) {
      console.error("Failed to update profile", err);
    }
  };

  if (!user) {
    return (
      <div className="flex items-center justify-center h-screen text-green-700">
        Loading profile...
      </div>
    );
  }

  return (
    <div className="min-h-[80vh] flex flex-col items-center justify-center bg-gradient-to-br from-emerald-50 to-emerald-100 py-10 px-4">
      <div className="bg-white/90 rounded-3xl shadow-2xl p-8 max-w-lg w-full flex flex-col items-center animate-fade-in-down">
        {/* Avatar */}
        <div className="relative mb-6">
          <img
  src={
    user?.avatar ||
    "https://cdn-icons-png.flaticon.com/512/3135/3135715.png" // 👈 default user image
  }
  alt="User Avatar"
  className="w-28 h-28 rounded-full border-4 border-emerald-200 shadow-lg object-cover"
/>

          <span className="absolute bottom-2 right-2 bg-emerald-600 text-white rounded-full px-2 py-1 text-xs font-semibold shadow">
            {user.role || "User"}
          </span>
        </div>

        {/* Info */}
        <h1 className="text-3xl font-black text-emerald-800 mb-2 tracking-tight drop-shadow-lg">
          {user.username}
        </h1>
        <p className="text-emerald-700 mb-6">{user.email}</p>

        {/* Editable Info */}
        {!edit ? (
          <div className="w-full">
            <div className="mb-3 flex items-center gap-2">
              <span className="font-semibold text-emerald-700">Phone:</span>
              <span>{form.phone || <span className="text-gray-400">Not set</span>}</span>
            </div>
            <div className="mb-3 flex items-center gap-2">
              <span className="font-semibold text-emerald-700">Address:</span>
              <span>{form.address || <span className="text-gray-400">Not set</span>}</span>
            </div>
            <button
              className="mt-6 bg-emerald-600 text-white px-6 py-2 rounded-full font-semibold shadow hover:bg-emerald-700 transition"
              onClick={() => setEdit(true)}
            >
              Edit Details
            </button>
          </div>
        ) : (
          <form className="w-full" onSubmit={handleSave}>
            <div className="mb-3">
              <label className="block text-emerald-700 font-semibold mb-1">
                Phone
              </label>
              <input
                type="text"
                name="phone"
                value={form.phone}
                onChange={handleChange}
                className="w-full border border-emerald-200 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-emerald-400"
                placeholder="Enter your phone number"
              />
            </div>
            <div className="mb-3">
              <label className="block text-emerald-700 font-semibold mb-1">
                Address
              </label>
              <input
                type="text"
                name="address"
                value={form.address}
                onChange={handleChange}
                className="w-full border border-emerald-200 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-emerald-400"
                placeholder="Enter your address"
              />
            </div>
            <div className="flex gap-3 mt-6">
              <button
                type="submit"
                className="bg-emerald-600 text-white px-6 py-2 rounded-full font-semibold shadow hover:bg-emerald-700 transition"
              >
                Save
              </button>
              <button
                type="button"
                className="bg-gray-200 text-emerald-700 px-6 py-2 rounded-full font-semibold shadow hover:bg-gray-300 transition"
                onClick={() => setEdit(false)}
              >
                Cancel
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};

export default Profile;
