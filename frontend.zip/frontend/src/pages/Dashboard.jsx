import React from "react";
import Card from "../components/Card";
import MapView from "../components/MapView";

const Dashboard = () => {
  return (
    <div className="min-h-[80vh] bg-gradient-to-br from-emerald-50 to-emerald-100 py-10 px-4 flex flex-col items-center">
      <h1 className="text-4xl font-black text-emerald-800 mb-10 tracking-tight drop-shadow-lg animate-fade-in-down">
        Dashboard
      </h1>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12 w-full max-w-6xl">
        <Card
          title="Total Bins"
          value="120"
          className="animate-fade-in-up"
          style={{ animationDelay: "0.1s" }}
        />
        <Card
          title="Bins Full"
          value="25"
          className="animate-fade-in-up"
          style={{ animationDelay: "0.2s" }}
        />
        <Card
          title="Avg Waste Level"
          value="58%"
          className="animate-fade-in-up"
          style={{ animationDelay: "0.3s" }}
        />
        <Card
          title="Alerts Today"
          value="7"
          className="animate-fade-in-up"
          style={{ animationDelay: "0.4s" }}
        />
      </div>

      {/* Map Section */}
      <div className="h-[500px] w-full max-w-6xl rounded-3xl shadow-2xl overflow-hidden bg-white/90 animate-fade-in-up" style={{ animationDelay: "0.5s" }}>
        <MapView />
      </div>

      {/* Animations */}
      <style>
        {`
          @keyframes fade-in-down {
            0% { opacity: 0; transform: translateY(-30px);}
            100% { opacity: 1; transform: translateY(0);}
          }
          @keyframes fade-in-up {
            0% { opacity: 0; transform: translateY(30px);}
            100% { opacity: 1; transform: translateY(0);}
          }
          .animate-fade-in-down {
            animation: fade-in-down 1s cubic-bezier(.4,0,.2,1) both;
          }
          .animate-fade-in-up {
            animation: fade-in-up 1s cubic-bezier(.4,0,.2,1) both;
          }
        `}
      </style>
    </div>
  );
};

export default Dashboard;
