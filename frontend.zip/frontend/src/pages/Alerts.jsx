import React, { useState } from "react";

const initialAlerts = [
  { id: 1, binId: 2, location: "Main Street", level: 85, status: "Pending" },
  { id: 2, binId: 5, location: "5th Avenue", level: 90, status: "Collected" },
  { id: 3, binId: 7, location: "Central Park", level: 88, status: "Pending" },
];

const getStatusColor = (status) =>
  status === "Collected"
    ? "bg-emerald-100 text-emerald-700"
    : "bg-red-100 text-red-700";

const getLevelColor = (level) =>
  level > 80
    ? "text-red-600"
    : level > 50
    ? "text-yellow-500"
    : "text-green-600";

const Alerts = () => {
  const [alerts, setAlerts] = useState(initialAlerts);

  const handleMarkCollected = (id) => {
    setAlerts((prev) =>
      prev.map((alert) =>
        alert.id === id ? { ...alert, status: "Collected" } : alert
      )
    );
  };

  return (
    <div className="min-h-[80vh] flex flex-col items-center justify-center bg-gradient-to-br from-emerald-50 to-emerald-100 py-10 px-4">
      <h1 className="text-3xl font-black text-emerald-800 mb-8 tracking-tight drop-shadow-lg animate-fade-in-down">
        Bin Alerts
      </h1>
      <div className="w-full max-w-2xl flex flex-col gap-6">
        {alerts.map((alert) => (
          <div
            key={alert.id}
            className="relative bg-white rounded-2xl shadow-lg p-6 flex flex-col md:flex-row items-center gap-6 hover:shadow-2xl transition-all duration-300 animate-fade-in-up cursor-pointer"
          >
            {/* Bin Icon */}
            <div className="flex-shrink-0 flex flex-col items-center">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="w-14 h-14 mb-2"
                viewBox="0 0 24 24"
                fill="none"
              >
                <g>
                  <rect
                    x="5"
                    y="7"
                    width="14"
                    height="12"
                    rx="3"
                    fill="#059669"
                    opacity="0.15"
                  />
                  <rect
                    x="5"
                    y="7"
                    width="14"
                    height="12"
                    rx="3"
                    stroke="#059669"
                    strokeWidth="2"
                  />
                  <path
                    d="M9 7V5a3 3 0 0 1 6 0v2"
                    stroke="#059669"
                    strokeWidth="2"
                    strokeLinecap="round"
                  />
                </g>
              </svg>
              <span className="text-xs text-gray-500">Bin #{alert.binId}</span>
            </div>
            {/* Alert Details */}
            <div className="flex-1 flex flex-col gap-2">
              <div className="flex items-center gap-2">
                <span className="font-semibold text-emerald-700">Location:</span>
                <span>{alert.location}</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="font-semibold text-emerald-700">Waste Level:</span>
                <span className={`font-bold ${getLevelColor(alert.level)}`}>
                  {alert.level}%
                </span>
                {alert.level > 80 && (
                  <span className="ml-2 text-red-500 animate-pulse">⚠️ High</span>
                )}
              </div>
              <div className="flex items-center gap-2">
                <span className="font-semibold text-emerald-700">Status:</span>
                <span
                  className={`px-3 py-1 rounded-full text-xs font-semibold ${getStatusColor(
                    alert.status
                  )}`}
                >
                  {alert.status}
                </span>
              </div>
            </div>
            {/* Action */}
            <div className="flex flex-col items-center mt-4 md:mt-0">
              {alert.status === "Pending" ? (
                <button
                  className="px-5 py-2 rounded-full font-semibold shadow transition-all duration-200 bg-emerald-600 text-white hover:bg-emerald-700"
                  onClick={() => handleMarkCollected(alert.id)}
                >
                  Mark Collected
                </button>
              ) : (
                <button
                  className="px-5 py-2 rounded-full font-semibold shadow bg-gray-200 text-gray-400 cursor-not-allowed"
                  disabled
                >
                  Mark Collected
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
      {/* Animations */}
      <style>
        {`
          @keyframes fade-in-down {
            0% { opacity: 0; transform: translateY(-30px);}
            100% { opacity: 1; transform: translateY(0);}
          }
          @keyframes fade-in-up {
            0% { opacity: 0; transform: translateY(30px);}
            100% { opacity: 1; transform: translateY(0);}
          }
          .animate-fade-in-down {
            animation: fade-in-down 1s cubic-bezier(.4,0,.2,1) both;
          }
          .animate-fade-in-up {
            animation: fade-in-up 1s cubic-bezier(.4,0,.2,1) both;
          }
        `}
      </style>
    </div>
  );
};

export default Alerts;
