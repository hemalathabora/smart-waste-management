import React from "react";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import "leaflet/dist/leaflet.css";

const bins = [
  { id: 1, lat: 40.7128, lng: -74.006, level: 45 },
  { id: 2, lat: 40.7228, lng: -74.001, level: 85 },
  { id: 3, lat: 40.7328, lng: -74.011, level: 60 },
];

const MapView = () => {
  return (
    <div className="w-full h-[600px] md:h-[500px] rounded-lg shadow">
      <MapContainer
        center={[40.7128, -74.006]}
        zoom={13}
        scrollWheelZoom={true}
        className="w-full h-full rounded-lg"
      >
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        />
        {bins.map((bin) => (
          <Marker key={bin.id} position={[bin.lat, bin.lng]}>
            <Popup>
              <div>
                <h2 className="font-bold">Bin ID: {bin.id}</h2>
                <p>Waste Level: {bin.level}%</p>
              </div>
            </Popup>
          </Marker>
        ))}
      </MapContainer>
    </div>
  );
};

export default MapView;
