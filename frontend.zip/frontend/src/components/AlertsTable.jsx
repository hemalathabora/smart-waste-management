import React from "react";

const alerts = [
  { id: 1, binId: 2, location: "Main Street", level: 85, status: "Pending" },
  { id: 2, binId: 5, location: "5th Avenue", level: 90, status: "Collected" },
];

const AlertsTable = () => {
  return (
    <div className="overflow-x-auto">
      <table className="min-w-full bg-white shadow rounded-lg">
        <thead className="bg-green-600 text-white">
          <tr>
            <th className="py-2 px-4">Bin ID</th>
            <th className="py-2 px-4">Location</th>
            <th className="py-2 px-4">Waste Level</th>
            <th className="py-2 px-4">Status</th>
            <th className="py-2 px-4">Action</th>
          </tr>
        </thead>
        <tbody>
          {alerts.map((alert) => (
            <tr key={alert.id} className="text-center border-b">
              <td className="py-2 px-4">{alert.binId}</td>
              <td className="py-2 px-4">{alert.location}</td>
              <td className="py-2 px-4">{alert.level}%</td>
              <td className="py-2 px-4">{alert.status}</td>
              <td className="py-2 px-4">
                <button className="bg-green-600 text-white px-3 py-1 rounded hover:bg-green-700">
                  Mark Collected
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default AlertsTable;
