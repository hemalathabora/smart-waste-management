import React, { useContext } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";

// Project short name: EcoBin

const navLinks = [
  { to: "/", label: "Home" },
  { to: "/dashboard", label: "Dashboard" },
  { to: "/analytics", label: "Analytics" },
  { to: "/alerts", label: "Alerts" },
  { to: "/admin", label: "Admin" },
  { to: "/profile", label: "Profile" },
];

const Navbar = () => {
  const { isLoggedIn, logout } = useContext(AuthContext);
  const location = useLocation();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <nav className="bg-white shadow-lg border-b border-emerald-100">
      <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
        {/* Brand */}
        <div className="flex items-center gap-2">
          {/* EcoBin recycling symbol */}
          <span className="text-emerald-600 text-3xl">
            ♻️
          </span>
          <span className="text-emerald-700 text-2xl font-black tracking-tight drop-shadow-lg">
            EcoBin
          </span>
        </div>
        {/* Navigation Links & Login/Signup */}
        <div className="flex items-center gap-4">
          <div className="flex gap-2 md:gap-4">
            {navLinks.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                className={`px-3 py-1.5 rounded-md font-medium text-sm transition 
                  ${
                    location.pathname === link.to
                      ? "bg-emerald-600 text-white shadow"
                      : "text-emerald-700 hover:bg-emerald-50"
                  }`}
              >
                {link.label}
              </Link>
            ))}
          </div>
          <div className="flex gap-2 ml-4">
            {!isLoggedIn ? (
              <>
                <Link
                  to="/login"
                  className="px-4 py-1.5 rounded-full bg-emerald-600 text-white font-semibold text-sm shadow hover:bg-emerald-700 transition"
                >
                  Login
                </Link>
                <Link
                  to="/signup"
                  className="px-4 py-1.5 rounded-full border border-emerald-600 text-emerald-700 font-semibold text-sm bg-white hover:bg-emerald-50 transition"
                >
                  Sign Up
                </Link>
              </>
            ) : (
              <button
                onClick={handleLogout}
                className="px-4 py-1.5 rounded-full bg-red-500 text-white font-semibold text-sm shadow hover:bg-red-600 transition"
              >
                Logout
              </button>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
